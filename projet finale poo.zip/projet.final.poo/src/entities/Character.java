package entities;

public abstract class Character {
    protected String name;
    protected int health;
    protected int maxHealth;
    protected int attack;
    protected int defense;
    protected int level;
    protected int x, y;
    
    public Character(String name, int health, int attack, int defense) {
        this.name = name;
        this.health = health;
        this.maxHealth = health;
        this.attack = attack;
        this.defense = defense;
        this.level = 1;
        this.x = 0;
        this.y = 0;
    }
    

    public int getX() { return x; }
    public int getY() { return y; }
    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }
    
    public boolean isAlive() {
        return health > 0;
    }
    
    public void takeDamage(int damage) {
        health -= damage;
        if (health < 0) health = 0;
    }
    
    public void heal(int amount) {
        health += amount;
        if (health > maxHealth) health = maxHealth;
    }
    
   
    public String getName() { return name; }
    public int getHealth() { return health; }
    public int getMaxHealth() { return maxHealth; }
    public int getAttack() { return attack; }
    public int getDefense() { return defense; }
    public int getLevel() { return level; }
    
   
    public void setAttack(int attack) { this.attack = attack; }
    public void setDefense(int defense) { this.defense = defense; }
    
    public void displayStats() {
        System.out.println("\n=== STATS DE " + name.toUpperCase() + " ===");
        System.out.println("Position: (" + x + "," + y + ")");
        System.out.println("Santé: " + health + "/" + maxHealth);
        System.out.println("Attaque: " + attack);
        System.out.println("Défense: " + defense);
        System.out.println("Niveau: " + level);
    }
}