package entities;

import java.util.Random;

public class Enemy extends Character {
    private String type;
    private Random random;
    
    public Enemy(String type, int health, int attack, int defense) {
        super(type, health, attack, defense);
        this.type = type;
        this.random = new Random();
    }
    
    public int attack() {
        int baseDamage = attack;
        int randomBonus = random.nextInt(6); 
        return baseDamage + randomBonus;
    }
    
    public void takeDamage(int damage) {
   
        if (random.nextInt(100) < 15) { 
            System.out.println(type + " esquive l'attaque!");
            return;
        }
        
        
        int reducedDamage = Math.max(1, damage - defense);
        super.takeDamage(reducedDamage);
        
        if (health <= 0) {
            System.out.println(type + " a été vaincu!");
        } else {
            System.out.println(type + " perd " + reducedDamage + " PV. Santé restante: " + health);
        }
    }
    
    public String getType() {
        return type;
    }
}