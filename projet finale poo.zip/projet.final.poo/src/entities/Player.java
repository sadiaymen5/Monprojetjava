package entities;

public class Player extends Character {
    private int experience;
    private int experienceToNextLevel;
    
    public Player(String name, int health, int attack, int defense) {
        super(name, health, attack, defense);
        this.experience = 0;
        this.experienceToNextLevel = 100;
    }
    
    public void gainExperience(int exp) {
        experience += exp;
        System.out.println("Expérience: " + experience + "/" + experienceToNextLevel);
        
        while (experience >= experienceToNextLevel) {
            levelUp();
        }
    }
    
    private void levelUp() {
        level++;
        experience -= experienceToNextLevel;
        experienceToNextLevel = (int)(experienceToNextLevel * 1.5);
        

        maxHealth += 25;
        health = maxHealth; 
        attack += 6;
        defense += 4;
        
        System.out.println("\n=== NIVEAU SUPÉRIEUR! ===");
        System.out.println("Vous êtes maintenant niveau " + level + "!");
        System.out.println("Santé max: " + maxHealth);
        System.out.println("Attaque: " + attack);
        System.out.println("Défense: " + defense);
    }
    
    public void moveTo(int newX, int newY) {
        this.x = newX;
        this.y = newY;
        System.out.println(name + " se déplace vers (" + x + "," + y + ")");
    }
    
   
    public void displayStats() {
        super.displayStats();
        System.out.println("Expérience: " + experience + "/" + experienceToNextLevel);
    }
}