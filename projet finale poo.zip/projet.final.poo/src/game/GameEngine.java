package game;

import entities.Player;
import entities.Enemy;
import combat.CombatSystem;
import java.util.Scanner;
import java.util.Random;

public class GameEngine {
    private Player player;
    private GameMap gameMap;
    private boolean gameRunning;
    private Scanner scanner;
    private Random random;
    
    public GameEngine() {
        this.scanner = new Scanner(System.in);
        this.random = new Random();
        this.gameRunning = true;
    }
    
    public void start() {
        System.out.println("=== JEU DE COMBAT AVEC CARTE ===");
        System.out.println("===============================\n");
        
        
        System.out.print("Entrez votre nom: ");
        String playerName = scanner.nextLine();
        player = new Player(playerName, 100, 15, 8);
        
       
        gameMap = new GameMap(15, 10, player);
        
        System.out.println("\nBienvenue, " + player.getName() + "!");
        System.out.println("Déplacez-vous avec Z/Q/S/D");
        System.out.println("Trouvez et combattez les ennemis (E)!");
        
        gameLoop();
    }
    
    private void gameLoop() {
        while (gameRunning && player.isAlive()) {
            gameMap.displayMap();
            displayMenu();
            String choice = scanner.nextLine().toLowerCase();
            
            switch(choice) {
                case "z": case "s": case "q": case "d":
                    handleMovement(choice);
                    break;
                case "m":
                    gameMap.displayMap();
                    break;
                case "r":
                    rest();
                    break;
                case "i":
                    player.displayStats();
                    break;
                case "c":
                    if (gameMap.hasEnemy()) {
                        Enemy enemy = gameMap.getCurrentEnemy();
                        startCombat(enemy);
                    } else {
                        System.out.println("Aucun ennemi à proximité!");
                    }
                    break;
                case "x":
                    explore();
                    break;
                case "p":  
                    gameRunning = false;
                    System.out.println("Au revoir!");
                    break;
                default:
                    System.out.println("Commande invalide!");
            }
        }
        
        if (!player.isAlive()) {
            System.out.println("\n=== GAME OVER ===");
            System.out.println("Vous avez été vaincu!");
        }
        
        scanner.close();
    }
    
    private void displayMenu() {
        System.out.println("\n=== COMMANDES ===");
        System.out.println("Z/S/Q/D - Se déplacer");
        System.out.println("M - Voir la carte");
        System.out.println("R - Se reposer (+20 PV)");
        System.out.println("I - Voir vos stats");
        System.out.println("C - Combattre l'ennemi à proximité");
        System.out.println("X - Explorer (chercher un ennemi)");
        System.out.println("P - Quitter");  
        System.out.print("\nVotre choix: ");
    }
    
    private void handleMovement(String direction) {
        boolean moved = gameMap.movePlayer(direction);
        
        if (moved) {
          
            Enemy enemyAtPosition = gameMap.getEnemyAt(player.getX(), player.getY());
            if (enemyAtPosition != null) {
                System.out.println("\n⚔️ COMBAT DÉCLENCHÉ! ⚔️");
                startCombat(enemyAtPosition);
            } else {
                System.out.println("Vous vous déplacez...");
            }
        }
    }
    
    private void startCombat(Enemy enemy) {
        CombatSystem combat = new CombatSystem(player, enemy);
        combat.startBattle();
        
        if (!enemy.isAlive()) {
            int expGained = 10 + random.nextInt(20);
            player.gainExperience(expGained);
            System.out.println("Vous gagnez " + expGained + " points d'expérience!");
            
           
            gameMap.removeEnemy();
            
          
            if (random.nextBoolean()) {
                findTreasure();
            }
        }
        
        if (!player.isAlive()) {
            gameRunning = false;
        }
    }
    
    private void rest() {
        int healAmount = 20;
        player.heal(healAmount);
        System.out.println("Vous vous reposez et récupérez " + healAmount + " points de vie.");
        System.out.println("Santé actuelle: " + player.getHealth() + "/" + player.getMaxHealth());
        
      
        if (random.nextInt(100) < 30) {
            System.out.println("Un ennemi vous a trouvé pendant votre repos!");
            gameMap.generateNewEnemy();
        }
    }
    
    private void explore() {
        System.out.println("Vous explorez les environs...");
        
        if (!gameMap.hasEnemy()) {
            if (random.nextInt(100) < 60) {
                gameMap.generateNewEnemy();
                System.out.println("Vous avez trouvé un nouvel ennemi!");
            } else {
                System.out.println("La zone semble calme...");
            }
        } else {
            System.out.println("Il y a déjà un ennemi sur la carte!");
        }
    }
    
    private void findTreasure() {
        String[] treasures = {"Potions", "Armure", "Arme", "Pièces d'or"};
        String treasure = treasures[random.nextInt(treasures.length)];
        
        switch(treasure) {
            case "Potions":
                player.heal(30);
                System.out.println("Vous trouvez des potions! +30 PV");
                break;
            case "Armure":
                player.setDefense(player.getDefense() + 2);
                System.out.println("Vous trouvez une armure! Défense +2");
                break;
            case "Arme":
                player.setAttack(player.getAttack() + 3);
                System.out.println("Vous trouvez une arme! Attaque +3");
                break;
            case "Pièces d'or":
                System.out.println("Vous trouvez un trésor en or!");
                break;
        }
    }
}