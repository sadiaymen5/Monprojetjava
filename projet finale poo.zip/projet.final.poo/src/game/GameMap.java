package game;

import entities.Player;
import entities.Enemy;
import java.util.Random;

public class GameMap {
    private char[][] grid;
    private int width;
    private int height;
    private Player player;
    private Enemy enemy;
    private Random random;
    
    public GameMap(int width, int height, Player player) {
        this.width = width;
        this.height = height;
        this.player = player;
        this.random = new Random();
        this.grid = new char[width][height];
        initializeMap();
        placePlayer();
    }
    
    private void initializeMap() {
       
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                if (x == 0 || y == 0 || x == width-1 || y == height-1) {
                    grid[x][y] = '#'; 
                } else {
                    grid[x][y] = '.';
                }
            }
        }
        
     
        addObstacles();
        
 
        generateEnemy();
    }
    
    private void addObstacles() {
       
        for (int i = 0; i < 10; i++) {
            int x = random.nextInt(width-2) + 1;
            int y = random.nextInt(height-2) + 1;
            if (grid[x][y] == '.') {
                grid[x][y] = 'T';
            }
        }
        
     
        for (int i = 0; i < 5; i++) {
            int x = random.nextInt(width-2) + 1;
            int y = random.nextInt(height-2) + 1;
            if (grid[x][y] == '.') {
                grid[x][y] = '~';
            }
        }
    }
    
    private void placePlayer() {
        int startX = width / 2;
        int startY = height / 2;
        player.setPosition(startX, startY);
        grid[startX][startY] = 'P';
    }
    
    private void generateEnemy() {
        String[] enemyTypes = {"Gobelin", "Orc", "Squelette", "Bandit"};
        String enemyType = enemyTypes[random.nextInt(enemyTypes.length)];
        
        int enemyX, enemyY;
        do {
            enemyX = random.nextInt(width-2) + 1;
            enemyY = random.nextInt(height-2) + 1;
        } while (grid[enemyX][enemyY] != '.');
        
        int enemyHealth = 20 + random.nextInt(30);
        int enemyAttack = 5 + random.nextInt(10);
        int enemyDefense = 3 + random.nextInt(7);
        
        enemy = new entities.Enemy(enemyType, enemyHealth, enemyAttack, enemyDefense);
        enemy.setPosition(enemyX, enemyY);
        grid[enemyX][enemyY] = 'E';
    }
    
    public boolean movePlayer(String direction) {
        int playerX = player.getX();
        int playerY = player.getY();
        int newX = playerX;
        int newY = playerY;
        
        switch(direction.toLowerCase()) {
            case "z": case "haut": newY--; break;
            case "s": case "bas": newY++; break;
            case "q": case "gauche": newX--; break;
            case "d": case "droite": newX++; break;
            default: return false;
        }
        
       
        if (!isValidMove(newX, newY)) {
            System.out.println("Mouvement impossible!");
            return false;
        }
        

        if (grid[newX][newY] == 'E') {
            System.out.println("Vous rencontrez un " + enemy.getType() + "!");
            return true; 
        }
        
      
        grid[playerX][playerY] = '.';
        grid[newX][newY] = 'P';
        player.setPosition(newX, newY);
        
        return true;
    }
    
    private boolean isValidMove(int x, int y) {
       
        if (x < 0 || x >= width || y < 0 || y >= height) {
            return false;
        }
        
       
        char tile = grid[x][y];
        return tile == '.' || tile == 'E'; 
    }
    
    public void displayMap() {
        System.out.println("\n" + "═".repeat(width * 2 + 2));
        System.out.println("CARTE (" + width + "x" + height + ")");
        System.out.println("═".repeat(width * 2 + 2));
        
        for (int y = 0; y < height; y++) {
            System.out.print("║");
            for (int x = 0; x < width; x++) {
                System.out.print(grid[x][y] + " ");
            }
            System.out.println("║");
        }
        
        System.out.println("═".repeat(width * 2 + 2));
        displayLegend();
    }
    
    private void displayLegend() {
        System.out.println("\nLÉGENDE:");
        System.out.println("P = Vous (Joueur)");
        System.out.println("E = Ennemi");
        System.out.println("# = Mur (impassable)");
        System.out.println("T = Arbre (impassable)");
        System.out.println("~ = Eau (impassable)");
        System.out.println(". = Sol (marchable)");
    }
    
    public Enemy getEnemyAt(int x, int y) {
        if (enemy != null && enemy.getX() == x && enemy.getY() == y) {
            return enemy;
        }
        return null;
    }
    
    public void removeEnemy() {
        if (enemy != null) {
            grid[enemy.getX()][enemy.getY()] = '.';
            enemy = null;
        }
    }
    
    public boolean hasEnemy() {
        return enemy != null;
    }
    
    public Enemy getCurrentEnemy() {
        return enemy;
    }
    
    public void generateNewEnemy() {
        if (!hasEnemy()) {
            generateEnemy();
        }
    }
}