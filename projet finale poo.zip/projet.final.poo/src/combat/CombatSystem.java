package combat;

import entities.Player;
import entities.Enemy;
import java.util.Scanner;
import java.util.Random;

public class CombatSystem {
    private Player player;
    private Enemy enemy;
    private Scanner scanner;
    private Random random;
    
    public CombatSystem(Player player, Enemy enemy) {
        this.player = player;
        this.enemy = enemy;
        this.scanner = new Scanner(System.in);
        this.random = new Random();
    }
    
    public void startBattle() {
        System.out.println("\n=== COMBAT ===");
        System.out.println(player.getName() + " VS " + enemy.getType());
        System.out.println("Position: (" + player.getX() + "," + player.getY() + ")");
        System.out.println("==============\n");
        
        boolean playerTurn = true;
        
        while (player.isAlive() && enemy.isAlive()) {
            if (playerTurn) {
                playerTurn(player);
            } else {
                enemyTurn();
            }
            
            playerTurn = !playerTurn;
            
          
            displayCombatStatus();
            
            if (!player.isAlive() || !enemy.isAlive()) {
                break;
            }
            
         
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        
        endBattle();
    }
    
    private void playerTurn(Player player) {
        System.out.println("\n--- VOTRE TOUR ---");
        System.out.println("1. Attaquer");
        System.out.println("2. Défendre (réduit les dégâts du prochain coup)");
        System.out.println("3. Utiliser potion (+30 PV)");
        System.out.print("\nVotre action: ");
        
        String choice = scanner.nextLine();
        
        switch(choice) {
            case "1":
                int playerDamage = calculatePlayerDamage();
                System.out.println(player.getName() + " attaque le " + enemy.getType() + "!");
                enemy.takeDamage(playerDamage);
                break;
                
            case "2":
                System.out.println(player.getName() + " se met en position défensive!");
                player.setDefense(player.getDefense() + 5);
                break;
                
            case "3":
                player.heal(30);
                System.out.println(player.getName() + " utilise une potion et récupère 30 PV!");
                System.out.println("Santé: " + player.getHealth() + "/" + player.getMaxHealth());
                break;
                
            default:
                System.out.println("Action invalide! Vous attaquez par défaut.");
                int defaultDamage = calculatePlayerDamage();
                enemy.takeDamage(defaultDamage);
        }
    }
    
    private void enemyTurn() {
        System.out.println("\n--- TOUR DE L'ENNEMI ---");
        
        if (!enemy.isAlive()) return;
        
        int enemyDamage = enemy.attack();
        System.out.println(enemy.getType() + " attaque " + player.getName() + "!");
        
    
        int damageToPlayer = Math.max(1, enemyDamage - player.getDefense());
        player.takeDamage(damageToPlayer);
        
        System.out.println(player.getName() + " perd " + damageToPlayer + " PV.");
        System.out.println("Santé restante: " + player.getHealth() + "/" + player.getMaxHealth());
        
      
        player.setDefense(Math.max(8, player.getDefense() - 5));
    }
    
    private int calculatePlayerDamage() {
        int baseDamage = player.getAttack();
        int randomBonus = random.nextInt(11); 
        
      
        boolean isCritical = random.nextInt(100) < 25;
        if (isCritical) {
            System.out.println("COUP CRITIQUE!");
            randomBonus *= 2;
        }
        
        return baseDamage + randomBonus;
    }
    
    private void displayCombatStatus() {
        System.out.println("\n--- ÉTAT DU COMBAT ---");
        System.out.println(player.getName() + ": " + player.getHealth() + "/" + player.getMaxHealth() + " PV");
        System.out.println(enemy.getType() + ": " + enemy.getHealth() + "/" + enemy.getMaxHealth() + " PV");
        System.out.println("----------------------");
    }
    
    private void endBattle() {
        if (player.isAlive()) {
            System.out.println("\n★ VICTOIRE! ★");
            System.out.println("Vous avez vaincu le " + enemy.getType() + "!");
        } else {
            System.out.println("\n✗ DÉFAITE ✗");
            System.out.println("Vous avez été vaincu par le " + enemy.getType() + "...");
        }
    }
}